import React from "react";
import MediaGridClient from "./MediaGrid.client";

const MediaGrid = (props: any) => {
	return <MediaGridClient />;
};

export default MediaGrid;
